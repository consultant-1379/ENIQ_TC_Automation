import re
from zipfile import ZipFile
import glob
import os
import shutil
f=0
g=0
h=0
l={}
l1={}
r=1
u=''
v=''
def zip(a,b):
	base=os.path.splitext(a)[0]
	os.rename(a,base+'.zip')
	a=base+'.zip'
	with ZipFile(base+'.zip', 'r') as zipObj:
		zipObj.extractall(b)
def zip1(a):
	b=a
	targetPattern=r"*.005"
	c=glob.glob(targetPattern)[0]
	zip(c,b)
	os.chdir(b)
	base=os.path.splitext('BusinessObjects.xml')[0]
	os.rename('BusinessObjects.xml',base+'.txt')
	os.chdir('../..')
def cmp(a,b):
	global c
	is_equal=a==b
	if is_equal:
		c=1
	else:
		c=0
def loop(a,s):
	s.write("\n")
	for i in a:
		s.write(i+' : '+a[i]+'\n')
def check(a,b):	
	global f,g,r,h,r,u,v
	base1=os.path.splitext(a)[0]
	os.rename(a,base1+'.txt')
	with open(a,'r') as e:
		for aline in e:
			if (b==2):
				y=re.search(r'<io:Name>atclvm(\d\d\d).*:6400</io:Name>',aline)
				if bool(y):
					if((y.group(1))=='885' or (y.group(1))=='886'):
						h=1
					u='Designed in atclvm'+y.group(1)+' server'
				x=re.search(r'<io:Name>(?!atclvm)(.*\d\d+.*)[^.wid]</io:Name>',aline)
				if bool(x):
					v='Package is having dependency as '+x.group(1)
					r=r*0
			z=re.search(r'<io:Description>(.+)\)',aline)
			if bool(z):
				if(b==1):
					p=z.group(1)
					for aline in e:
						o=re.search(r'<io:CUID>(.+)</io:CUID>',aline)
						if bool(o):
							l[p+')']=o.group(1)
							break
					f=f+1;
				else:
					q=z.group(1)
					for aline in e:
						o=re.search(r'<io:CUID>(.+)</io:CUID>',aline)
						if bool(o):
							l1[q+')']=o.group(1)
							break
					g=g+1;
	e.close()
	if (h==0):
		if (b==2):
			os.chdir('new')
			base=os.path.splitext('BusinessObjects.xml')[0]
			os.rename('BusinessObjects.xml',base+'.txt')
			os.chdir('..')
			a='new/BusinessObjects.txt'
			base1=os.path.splitext(a)[0]
			os.rename(a,base1+'.txt')
			with open(a,'r') as e:
				for aline in e:
					y=re.search(r'<io:Name>atclvm(\d\d\d).*:6400</io:Name>',aline)
					if bool(y):
						if((y.group(1))=='885' or (y.group(1))=='886'):
							h=1
						u='Designed in atclvm'+y.group(1)+' server'
			e.close()				
	cmp(l,l1)
print "Select the operation to be performed:\n1.COMPARISON (Report comparison and server & dependency check)\n2.SERVER & DEPENDENCY CHECK\n"
t=raw_input("Enter 1 or 2: ")
if(t=='1'):
	o1=raw_input("Enter the previous lcmbiar file name with extension(eg.ERIC_CUDB_Basic_Report_Package_R1A01.lcmbiar):")
	n1=raw_input("Enter the new lcmbiar file name with extension(eg.ERIC_CUDB_Basic_Report_Package_R1A01.lcmbiar):")
	open("output.txt","w").close()
	s=open("output.txt","a")
	s.write("----------------------------------------------\nOld Package: "+o1+"\nNew Package: "+n1+"\n")
	zip(o1,'old')
	zip(n1,'new')
	print('Successfully extracted! ')
	os.chdir('old')
	zip1('old1')
	os.chdir('new')
	zip1('new1')
	m='PASS'
	n='FAIL'
	check('old/old1/BusinessObjects.txt',1)
	check('new/new1/BusinessObjects.txt',2)
	s.write("----------------------------------------------\n----------------------------------------------\nCOMPARISON RESULTS\n----------------------------------------------")
	if(h==1):
		s.write("\nDESIGN SERVER: "+m+"\n"+u+"\n----------------------------------------------")
	else:
		s.write("\nDESIGN SERVER: "+n+"\n"+u+"\n----------------------------------------------")
		#print(u)
	if(r==1):
		s.write("\nDEPENDENCY: "+m+"\nNo Dependency\n----------------------------------------------")
	else:
		s.write("\nDEPENDENCY: "+n+"\n"+v+"\n----------------------------------------------")
	if(f==g):
		s.write("\nREPORTS: "+m+"\nNo. of Reports in both packages = "+str(f)+"\n----------------------------------------------")
	else:
		s.write("\nREPORTS: "+n+"\n")
		s.write("\nNo. of Reports in "+o1+" : "+str(f))
		s.write("\nNo. of Reports in "+n1+" : "+str(g))
		s.write("\n----------------------------------------------")
	if(c==1):
		s.write("\nCUID MATCH: "+m+"\nReport CUIDs are matching\n----------------------------------------------\n----------------------------------------------")
	else:
		s.write("\nCUID MATCH: "+n+"\n")
		s.write("\nCUIDs in "+o1+" : \n")
		loop(l,s)
		s.write("\n")
		s.write("\nCUIDs in "+n1+" : \n")
		loop(l1,s)
		s.write("\n----------------------------------------------\n----------------------------------------------")
	shutil.rmtree('old')
	shutil.rmtree('new')
	for f in os.listdir(os.getcwd()):
		if f.endswith('.zip'):
			os.remove(f)
	s.close()
	s=open("output.txt","r")
	print(s.read())
	s.close()
elif(t=='2'):
	n=raw_input("Enter the lcmbiar file name with extension(eg.ERIC_CUDB_Basic_Report_Package_R1A01.lcmbiar):")
	open("output.txt","w").close()
	s=open("output.txt","a")
	s.write("----------------------------------------------\nPackage: "+n+"\n")
	zip(n,'new')
	print('Successfully etracted! ')
	os.chdir('new')
	zip1('new1')
	m='PASS'
	n='FAIL'
	check('new/new1/BusinessObjects.txt',2)
	s.write("----------------------------------------------\n----------------------------------------------\nRESULTS\n----------------------------------------------")
	if(h==1):
		s.write("\nDESIGN SERVER: "+m+"\n"+u+"\n----------------------------------------------")
	else:
		s.write("\nDESIGN SERVER: "+n+"\n"+u+"\n----------------------------------------------")
		#print(u)
	if(r==1):
		s.write("\nDEPENDENCY: "+m+"\nNo Dependency\n----------------------------------------------\n----------------------------------------------")
	else:
		s.write("\nDEPENDENCY: "+n+"\n"+v+"\n----------------------------------------------\n----------------------------------------------")
	shutil.rmtree('new')
	for f in os.listdir(os.getcwd()):
		if f.endswith('.zip'):
			os.remove(f)
	s.close()
	s=open("output.txt","r")
	print(s.read())
	s.close()
else:
	print "Invalid choice!\n"